<?php
/********************************************************************************
 *                             CHEFS DE PROJETS : P.BAFFALIE, S.GRESSARD
 *                             MODULE : package_name
 *                             PROJET : promethee
 * 
 * Description :                
 *                             -
 * Environnement PHP   : PHP4 OU PHP5
 * @author                    : nordine.zetoutou
 * @date date de cr�ation     : 17 nov. 06 
 * Historique de modification :
 *                             -
 *                             -
 * @version                   :	1.0
 *
 ********************************************************************************/

 echo
 "<p style='color:red;font-weight:bold;'> ************* </br>".
 dirname(__FILE__)
 ."</br>*************</p>";
  
?>
