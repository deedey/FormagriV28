<?php
$nom_table = 'ressource_new';
$champs = 'ress_cdn,ress_typress_no,ress_titre,ress_url_lb,ress_cat_lb,ress_desc_cmt,ress_publique_on,ress_auteurs_cmt,ress_ajout';
$cfg_nb_pages = 10; // Nombre de n� de pages affich�s dans la barre
$signe="<B> >> </B>";
$objet="ref_denom_lb";
$ordre="ref_cdn";
$nom_abrege="ref_nomabrege_lb";
$nom_du_pere="ref_nomparent_lb";
$pere="ref_parent_no";
$auteurs="ref_auteur_lb";
$champ="ref_local_on";
$nom_ref="ref_nom_lb";
$descriptif="ref_desc_cmt";
$nivea="ref_niv_no";
$domaine="ref_dom_lb";
?>
