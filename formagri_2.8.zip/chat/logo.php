<HTML><HEAD><link REL='StyleSheet' TYPE='text/css' HREF='chat.css'></HEAD>
<BODY>
<CENTER><A href="http://www.toutjavascript.com/chat" target=_blank><IMG src="tjschat.gif" width=90 height=31 alt="Tout JavaScript.com" border=0></A></CENTER>
</BODY></HTML>